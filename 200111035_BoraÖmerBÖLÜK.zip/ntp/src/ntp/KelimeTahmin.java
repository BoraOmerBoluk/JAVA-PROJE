package ntp;
import java.util.*;

public class KelimeTahmin {
	int kontrol = 0;
	Scanner a = new Scanner(System.in);
    public KelimeTahmin() {
    	{ 
    		while (kontrol == 0 ) {
		    	System.out.println("\n--AD TAHM�N� OYUNUNA HO�GELD�N�Z--");
		    	System.out.println("\n--��lemlerinizi Kolayl�k �le Yapman�z Dile�iyle--\n");
		        System.out.println("ANA MEN�'YE D�NMEK ���N '1' G�R�N�Z.  \n");
		       System.out.println("AD TAHM�N� OYUNUNA DEVAM ETMEK ���N '2' G�R�N�Z.\n");
		       int girdi= a.nextInt();
			    switch (girdi) {
			    case 1:
			    	new ANA_MEN�();
			    	break;
			    case 2:
    		String[] depo = { "Bora", "Omer", "Boluk", "Ay�e", "Sinem", "Buse", "Mehmet", "Eliza", "Mahmud", "Hasan" };
    		Random r = new Random();
    		Scanner s = new Scanner(System.in);
    		int indis = r.nextInt(10); //ISIM DIZISINDEN RASTGELE BIR ISIM ALMAK ICIN INDIS SECIYORUZ
    		int i, uzunluk, j, z;
    		String isim = depo[indis].toLowerCase(); //ISIMDEKI HARFLERI KUCUK HARFE CEVIRDIK
    		//System.out.println(isim);
    		System.out.println( "Bora, Omer, Boluk, Ay�e, Sinem, Buse, Mehmet, Eliza, Mahmud , Hasan \n\n YUKARIDAK� �S�MLERDEN B�R�N� TAHM�N ETMEN�Z GEREKMEKTED�R.");
    		uzunluk = isim.length();
    		char[] kelime = new char[uzunluk];
    		for (i = 0; i < uzunluk; i++) {
    			kelime[i] = '-';
    		}
    		for (i = 0; i < uzunluk; i++) {
    			System.out.print("_ ");
    		}
    		for (j = 0; j < 5; j++) {
    			System.out.println("\nK���K HARF KULLANINIZ");
    			char input = s.next().charAt(0); //KULLANICININ GIRDIGI KUCUK HARFIN KELIMEDE OLUP OLMADIGINI VARSA KELIMEDE GOZUKMESINI SAGLIYORUZ
    			for (z = 0; z < uzunluk; z++) {
    				if (isim.charAt(z) == input) {
    					kelime[z] = input;
    				}
    			}
    			for (i = 0; i < uzunluk; i++) {
    				System.out.print(kelime[i] + " ");
    			}
    		}
    		break;
    	}
    }
    	}
    }
}
