package ntp;
import java.util.*; //T�m k�t�phaneleri dahil eder
// !!!ASLINDA BU DA HATALI ANA MEN�YE GER� D�NEM�YORUM FAKAT YEN� ATTI�IM T�M ZARLARI KAYIT EDEREK DAHA �NCEK� ZAR KAYITLARI �LE B�RL�KTE G�R�NT�LEYEB�L�YORUZ.!!!
public class zar {
	  public zar(){
			int kontrol = 0,counter=0;
			int a=0,b=0;
			int j;
			int[] zar1 = new int[100]; //ZAR KAYITLARI
			int[] zar2 = new int[100];
			Scanner s = new Scanner(System.in);
			Random r = new Random();

			while (kontrol == 0 ) {
		    	System.out.println("\n--ZAR ATMA UYGULAMASINA HO�GELD�N�Z--");
		    	System.out.println("\n--��lemlerinizi Kolayl�k �le Yapman�z Dile�iyle--\n");
		        System.out.println("ANA MEN�'YE D�NMEK ���N '1' G�R�N�Z.  \n");
		       System.out.println("YEN� ZAR ATARAK KAYDETMEK ���N '2' G�R�N�Z.\n");
		       System.out.println("ESK� ZAR KAYITLARI G�R�NT�LEMEK ���N '3' G�R�N�Z.");
		       
		        int girdi= s.nextInt();
		        
		    switch (girdi) {
		    
		    case 1:
		    	new ANA_MEN�();
		    	break;
				case 2:
					a=r.nextInt(6)+1;
					b=r.nextInt(6)+1; //1-6 ARASINDA RANDOM SAYI SECIYORUZ 1 6 DAHIL
					System.out.println("1. ZAR: "+a +" 2. ZAR:"+ b);
						zar1[counter]=a;
						zar2[counter]=b; //SONUCLAR KAYDOLSUN DERSE ZARLARIN SONUCU KAYDOLUYOR
						counter++; //KAC ZAR KAYDI OLDUGUNU TUTUYORUZ SAYACTA
						System.out.println("\nDAHA �NCEDEN TUTTU�UNUZ ZAR KAYITLARI:\n");
						for (j=0;j<counter;j++) {
							System.out.println("1. ZAR: "+zar1[j]+" 2. ZAR: "+zar2[j]);} 	
					
		    break;
					case 3:
						for (j=0;j<counter;j++) {
						System.out.println("1. ZAR: "+zar1[j]+" 2. ZAR: "+zar2[j]);}
					
		    		break;	
}
}		
}
}
//!!!ASLINDA BU DA HATALI ANA MEN�YE GER� D�NEM�YORUM FAKAT YEN� ATTI�IM T�M ZARLARI KAYIT EDEREK DAHA �NCEK� ZAR KAYITLARI �LE B�RL�KTE G�R�NT�LEYEB�L�YORUZ.!!!
